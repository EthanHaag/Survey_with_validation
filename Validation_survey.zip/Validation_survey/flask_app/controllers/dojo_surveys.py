from flask import render_template, redirect, request, session
from flask_app import app
from flask_app.models.dojo_survey import Dojo_survey 
@app.route('/')
def runapp():
    return render_template ('index.html')
@app.route('/load',methods=['POST'])
def process():
    Dojo_survey.save(request.form)
    if not Dojo_survey.validate(request.form):
        return redirect ('/')
    
    
    return redirect('/result')
@app.route('/result')
def success():
    return render_template('results.html', dojo= Dojo_survey.get_last_survey())